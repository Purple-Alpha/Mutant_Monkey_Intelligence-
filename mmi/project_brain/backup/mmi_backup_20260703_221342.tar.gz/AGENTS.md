# Current MMI Scope Override

For active MMI work, this legacy Social Architect swarm chart is not authoritative. Follow `CODEX.md` and `mmi/project_brain/` first. If this file conflicts with MMI project-brain files or `tasks.json`, the MMI files win.

# Agent Organizational Chart - Hierarchical Swarm Architecture

## Overview
This document defines the hierarchical structure for the Social Architect AI swarm system, mapping agent roles, permissions, and escalation paths.

## Architecture Tiers

### Tier 1: Project Managers (PM)
**Models:** Claude + Codex
**Role:** Strategic planning, task decomposition, quality control
**Permissions:** 
- Read all project files and documentation
- Create and assign tasks to lower tiers
- Access all agent outputs and logs
- Escalate to human oversight if needed
- Modify CLAUDE.md memory files

### Tier 2: Foremen 
**Models:** MAVEN + SAGE
**Role:** Crew coordination, specialized execution, quality assurance
**Permissions:**
- Execute assigned tasks within defined scope
- Read task specifications and requirements
- Access build outputs and intermediate files
- Report progress and issues to PM tier
- Access specialized tools and libraries

### Tier 3: Trades (Specialized Workers)
**Models:** DAX + HAVEN
**Role:** Specific technical implementation, testing, validation
**Permissions:**
- Execute narrowly defined technical tasks
- Read specific file types and data structures
- Run tests and validation scripts
- Report results to Foremen tier
- Access limited, task-specific tools

### Tier 4: Laborers (Task Workers)
**Role:** Single-task execution, data processing
**Permissions:**
- Execute specific, assigned commands
- Read designated input files
- Write to specified output locations
- No access to project-wide files or tools

## Communication Protocol

### Escalation Path
```
Laborer → Trades → Foremen → PM → Human Oversight
```

### Task Assignment Flow
1. **PM receives requirement** from BUILD_QUEUE.json or human input
2. **PM creates task breakdown** and assigns to appropriate Foremen
3. **Foremen coordinate** Trades workers for execution
4. **Trades execute** specific tasks within their domain
5. **Results flow back** through Foremen to PM for validation
6. **PM updates** CLAUDE.md with completion status

## Tool Access Matrix

| Agent Tier | Code Execution | File System | Network Access | API Keys |
|-------------|---------------|-------------|---------------|-----------|
| PM (Claude) | ✅ | ✅ | ✅ | ✅ |
| Foremen (MAVEN/SAGE) | ✅ | ✅ | ⚠️ | ⚠️ |
| Trades (DAX/HAVEN) | ⚠️ | ⚠️ | ❌ | ❌ |
| Laborers | ❌ | ❌ | ❌ | ❌ |

## Crew Folder Structure
```
crews/
├── project_managers/
│   ├── claude_pm.py
│   └── codex_pm.py
├── foremen/
│   ├── maven_foreman.py
│   └── sage_foreman.py
├── specialized_trades/
│   ├── dax_trader.py
│   └── haven_trader.py
├── tools/
│   ├── code_executor.py
│   ├── file_manager.py
│   └── api_client.py
└── laborers/
    ├── task_worker.py
    └── data_processor.py
```

## Role Boundaries

### PM (Claude + Codex)
- **Strategic Planning:** Define project architecture and milestones
- **Task Decomposition:** Break complex work into executable units
- **Quality Control:** Review all outputs before human delivery
- **Resource Management:** Allocate compute and storage resources
- **Human Interface:** Final approval and stakeholder communication

### Foremen (MAVEN + SAGE)
- **Crew Coordination:** Manage task execution across multiple agents
- **Specialized Execution:** Implement domain-specific solutions
- **Progress Tracking:** Monitor task completion and quality metrics
- **Issue Resolution:** Debug and fix execution problems

### Trades (DAX + HAVEN)
- **Technical Implementation:** Write code, build systems, configure tools
- **Testing & Validation:** Unit tests, integration tests, quality checks
- **Documentation:** Code comments, API docs, user guides
- **Performance Optimization:** Speed, memory usage, efficiency improvements

### Laborers
- **Single Task Focus:** Execute one specific command or function
- **Data Processing:** Transform, validate, format data
- **File Operations:** Read/write specific files as instructed
- **Reporting:** Return execution results to superiors

## Escalation Rules

1. **Timeout:** Any task running > 30 minutes escalates automatically
2. **Failure:** 3 consecutive failures escalate to Foreman + PM
3. **Quality:** PM can reject any output not meeting standards
4. **Security:** Any attempt to access unauthorized resources triggers immediate escalation

## Integration Points

- **CLAUDE.md:** PM updates project memory and status
- **BUILD_QUEUE.json:** Human input and task queue
- **Guardrails:** Safety and compliance checking
- **ntfy:** Notification system for human oversight
- **Slack:** Team communication and coordination

This architecture ensures clear role separation, proper escalation paths, and scalable coordination for complex AI swarm operations.
