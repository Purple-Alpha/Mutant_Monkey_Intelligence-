# Deploy Phase 4E rev_c fixes (Codex NOT CLEAN response) — Admin; stops minifilter briefly.
param(
    [string]$RepoRoot = "C:\Architectapp_clean",
    [string]$StagingRoot = "C:\mmi_boundary_scratch\4e_build_staging_rev_c"
)

$ErrorActionPreference = "Stop"

function Test-Admin {
    $current = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
    return $current.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Admin)) {
    throw "Run as Administrator."
}

Write-Host "Stopping mmi_boundary..."
& sc.exe stop mmi_boundary 2>&1 | Out-Null
Start-Sleep -Seconds 2

$copyMap = @(
    @{ Src = "mmi\m4\wfp_policy.py"; Dst = "mmi\m4\wfp_policy.py" },
    @{ Src = "mmi\m4\authority_seal.py"; Dst = "mmi\m4\authority_seal.py" },
    @{ Src = "scripts\m4_authority_seal.py"; Dst = "scripts\m4_authority_seal.py" },
    @{ Src = "scripts\install_m4_wfp.ps1"; Dst = "scripts\install_m4_wfp.ps1" },
    @{ Src = "host_boundary\mmi_wfp\mmi_wfp_helper.cpp"; Dst = "host_boundary\mmi_wfp\mmi_wfp_helper.cpp" },
    @{ Src = "host_boundary\mmi_wfp\README.md"; Dst = "host_boundary\mmi_wfp\README.md" },
    @{ Src = "tests\test_m4_wfp_policy.py"; Dst = "tests\test_m4_wfp_policy.py" }
)

foreach ($item in $copyMap) {
    $src = Join-Path $StagingRoot $item.Src
    $dst = Join-Path $RepoRoot $item.Dst
    if (-not (Test-Path $src)) { throw "Missing staging file: $src" }
    $dstDir = Split-Path -Parent $dst
    New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
    Copy-Item -Path $src -Destination $dst -Force
    Write-Host "Deployed $($item.Dst)"
}

Write-Host "Reloading filter..."
& sc.exe start mmi_boundary 2>&1 | Out-Null
Start-Sleep -Seconds 2
& (Join-Path $RepoRoot "scripts\install_m4_minifilter.ps1") -SkipBuild

Write-Host ""
Write-Host "4E rev_c deployed. Next (Admin):"
Write-Host "  cd $RepoRoot"
Write-Host "  .\scripts\build_m4_wfp.ps1"
Write-Host "  .\scripts\install_m4_wfp.ps1"
Write-Host "  python scripts\m4_wfp_suite.py --live --json"
