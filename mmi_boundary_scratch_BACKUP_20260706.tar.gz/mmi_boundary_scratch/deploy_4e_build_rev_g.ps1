# Deploy WFP DevShell build fix (rev_g) — Admin; stops minifilter briefly.
param(
    [string]$RepoRoot = "C:\Architectapp_clean",
    [string]$StagingRoot = "C:\mmi_boundary_scratch\4e_build_staging_rev_c"
)

$ErrorActionPreference = "Stop"

Write-Host "Stopping mmi_boundary..."
& sc.exe stop mmi_boundary 2>&1 | Out-Null
Start-Sleep -Seconds 2

Copy-Item (Join-Path $StagingRoot "scripts\build_m4_wfp.ps1") (Join-Path $RepoRoot "scripts\build_m4_wfp.ps1") -Force
Copy-Item (Join-Path $StagingRoot "host_boundary\mmi_wfp\mmi_wfp_helper.vcxproj") (Join-Path $RepoRoot "host_boundary\mmi_wfp\mmi_wfp_helper.vcxproj") -Force
Write-Host "Deployed rev_g build script + vcxproj"

& sc.exe start mmi_boundary 2>&1 | Out-Null
Start-Sleep -Seconds 2
& (Join-Path $RepoRoot "scripts\install_m4_minifilter.ps1") -SkipBuild

Write-Host "Done. Use Developer PowerShell for VS 2022 (Admin) — see build output."
