$path = 'C:\Architectapp_clean\mmi\m4\minifilter_policy.py'
$content = [System.IO.File]::ReadAllText($path)

if ($content -match 'mkdir_parents:\s*bool\s*=') {
    Write-Host 'Already patched (function signature ok)'
    exit 0
}

$pattern = '(?s)def attempt_live_write\(path: Path, payload: str = "probe"\) -> tuple\[bool, str \| None\]:.*?return False, str\(exc\)'

$newFn = @'
def attempt_live_write(
    path: Path,
    payload: str = "probe",
    *,
    mkdir_parents: bool = True,
) -> tuple[bool, str | None]:
    """Return (write_succeeded, error_message)."""
    try:
        if mkdir_parents:
            path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(payload, encoding="utf-8")
        return True, None
    except OSError as exc:
        return False, str(exc)
'@

$updated = [regex]::Replace($content, $pattern, $newFn)
if ($updated -eq $content) {
    Write-Error 'Function replace failed — pattern not found'
    exit 1
}

$updated = $updated.Replace('attempt_live_write(probe)', 'attempt_live_write(probe, mkdir_parents=False)')
$updated = $updated.Replace('attempt_live_write(scratch_probe)', 'attempt_live_write(scratch_probe, mkdir_parents=True)')

[System.IO.File]::WriteAllText($path, $updated)
Write-Host 'Patched minifilter_policy.py (function + call sites)'
