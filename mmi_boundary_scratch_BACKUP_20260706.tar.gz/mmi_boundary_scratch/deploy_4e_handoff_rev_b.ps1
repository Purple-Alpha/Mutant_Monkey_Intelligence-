$ErrorActionPreference = 'Stop'
Write-Host 'Stopping mmi_boundary...'
& sc.exe stop mmi_boundary | Out-Null
Start-Sleep -Seconds 3

$dest = 'C:\Architectapp_clean\mmi\project_brain\lanes'
$src  = 'C:\mmi_boundary_scratch\4e_handoff_staging\lanes'
Copy-Item (Join-Path $src 'CURSOR_HANDOFF_4E_WFP_BUILD_PLAN_2026-07-05.md') $dest -Force

Write-Host 'Deployed rev b:'
Get-Item (Join-Path $dest 'CURSOR_HANDOFF_4E_WFP_BUILD_PLAN_2026-07-05.md') | Format-List Name, Length, LastWriteTime

Write-Host 'Reloading filter...'
Set-Location 'C:\Architectapp_clean'
& .\scripts\install_m4_minifilter.ps1 -AuthorityRoot 'C:\Architectapp_clean' -SkipBuild
