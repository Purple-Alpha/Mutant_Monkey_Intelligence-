# Deploy WFP vcvars64 build fix (rev_e) — Admin; stops minifilter briefly for script copy.
param(
    [string]$RepoRoot = "C:\Architectapp_clean",
    [string]$StagingRoot = "C:\mmi_boundary_scratch\4e_build_staging_rev_c"
)

$ErrorActionPreference = "Stop"

function Test-Admin {
    $current = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
    return $current.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Admin)) {
    throw "Run as Administrator."
}

Write-Host "Stopping mmi_boundary..."
& sc.exe stop mmi_boundary 2>&1 | Out-Null
Start-Sleep -Seconds 2

Copy-Item (Join-Path $StagingRoot "scripts\build_m4_wfp.ps1") (Join-Path $RepoRoot "scripts\build_m4_wfp.ps1") -Force
Write-Host "Deployed scripts\build_m4_wfp.ps1"

Write-Host "Reloading filter..."
& sc.exe start mmi_boundary 2>&1 | Out-Null
Start-Sleep -Seconds 2
& (Join-Path $RepoRoot "scripts\install_m4_minifilter.ps1") -SkipBuild

Write-Host ""
Write-Host "rev_e deployed. Next:"
Write-Host "  cd $RepoRoot"
Write-Host "  .\scripts\build_m4_wfp.ps1"
Write-Host "  .\scripts\install_m4_wfp.ps1"
Write-Host "  python scripts\m4_wfp_suite.py --live --json"
