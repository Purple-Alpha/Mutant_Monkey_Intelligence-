# Deploy build_wfp_devshell.ps1 — stops minifilter briefly.
$ErrorActionPreference = "Stop"
Write-Host "Stopping mmi_boundary..."
& sc.exe stop mmi_boundary 2>&1 | Out-Null
Start-Sleep -Seconds 2
Copy-Item "C:\mmi_boundary_scratch\4e_build_staging_rev_c\scripts\build_wfp_devshell.ps1" `
    "C:\Architectapp_clean\scripts\build_wfp_devshell.ps1" -Force
Write-Host "Deployed scripts\build_wfp_devshell.ps1"
& sc.exe start mmi_boundary 2>&1 | Out-Null
Start-Sleep -Seconds 2
& "C:\Architectapp_clean\scripts\install_m4_minifilter.ps1" -SkipBuild
Write-Host "Done. Run: .\scripts\build_wfp_devshell.ps1"
