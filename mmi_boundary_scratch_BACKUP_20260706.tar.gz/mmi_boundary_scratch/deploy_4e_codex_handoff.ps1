$ErrorActionPreference = 'Stop'
$dest = 'C:\Architectapp_clean\mmi\project_brain\lanes'
$src = 'C:\mmi_boundary_scratch\4e_handoff_staging\lanes'

Write-Host 'Stopping mmi_boundary so authority tree is writable...'
& sc.exe stop mmi_boundary | Out-Null
Start-Sleep -Seconds 2

New-Item -ItemType Directory -Path $dest -Force | Out-Null
Copy-Item (Join-Path $src 'CURSOR_HANDOFF_4E_WFP_BUILD_PLAN_2026-07-05.md') $dest -Force
Copy-Item (Join-Path $src 'RESEARCH_M4_4D_B_TO_4E_PERFECTION_GAP_2026-07.md') $dest -Force
Copy-Item (Join-Path $src 'RESEARCH_FILING_CROSSREPO_4E_2026-07-05.md') $dest -Force

Write-Host 'Deployed:'
Get-ChildItem $dest -Filter '*4E*' | Select-Object Name, Length, LastWriteTime

Write-Host 'Reloading filter...'
Set-Location 'C:\Architectapp_clean'
& .\scripts\install_m4_minifilter.ps1 -AuthorityRoot 'C:\Architectapp_clean' -SkipBuild

Write-Host 'Done. Re-run Codex plan review against:'
Write-Host '  mmi/project_brain/lanes/CURSOR_HANDOFF_4E_WFP_BUILD_PLAN_2026-07-05.md'
