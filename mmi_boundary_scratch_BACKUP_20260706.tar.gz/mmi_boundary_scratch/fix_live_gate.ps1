# One-shot: stop filter, patch suite, reload, run live gate.
$ErrorActionPreference = 'Stop'

Write-Host 'Stopping mmi_boundary...'
& sc.exe stop mmi_boundary | Out-Null
Start-Sleep -Seconds 2

Remove-Item -Recurse -Force 'C:\Architectapp_clean\mmi_m4_boundary_probe' -ErrorAction SilentlyContinue

Write-Host 'Patching minifilter_policy.py...'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'C:\mmi_boundary_scratch\patch_minifilter_policy.ps1'

Write-Host 'Reloading filter...'
Set-Location 'C:\Architectapp_clean'
& .\scripts\install_m4_minifilter.ps1 -AuthorityRoot 'C:\Architectapp_clean' -SkipBuild

Write-Host 'Running live gate...'
& python scripts\m4_minifilter_suite.py --live --json
