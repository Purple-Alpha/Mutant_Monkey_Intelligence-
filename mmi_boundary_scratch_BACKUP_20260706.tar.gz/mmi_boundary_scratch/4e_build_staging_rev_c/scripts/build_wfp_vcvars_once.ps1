# One-shot build via vcvars64 (no Launch-VsDevShell). Safe for WSL-invoked powershell.exe.
$ErrorActionPreference = 'Stop'
Set-Location C:\

$bat = 'C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat'
$out = 'C:\mmi_boundary_scratch\mmi_wfp_build\x64\Release'
$obj = Join-Path $out 'obj\mmi_wfp_helper.obj'
$exe = Join-Path $out 'mmi_wfp_helper.exe'
$src = 'C:\mmi_boundary_scratch\4e_build_staging_rev_c\host_boundary\mmi_wfp\mmi_wfp_helper.cpp'

New-Item -ItemType Directory -Force -Path (Split-Path $obj), $out | Out-Null

$inner = @(
    "call `"$bat`""
    "cd /d `"$out`""
    "cl /nologo /EHsc /O2 /W3 /c /Fo`"$obj`" `"$src`""
    "link /nologo /OUT:`"$exe`" `"$obj`" fwpuclnt.lib rpcrt4.lib advapi32.lib ws2_32.lib"
) -join ' && '

cmd /c $inner
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
if (-not (Test-Path $exe)) { throw "Missing $exe" }
Write-Host "OK: $exe size=$((Get-Item $exe).Length)"
