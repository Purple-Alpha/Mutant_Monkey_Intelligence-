# Build mmi_wfp_helper.exe via VS Dev Shell + cl.exe (no MSBuild/props).
# Works with VS 2022 Community (17.x) or Build Tools 2026 (18.x).
param(
    [string]$ScratchRoot = "C:\mmi_boundary_scratch\mmi_wfp_build",
    [string]$RepoRoot = "C:\Architectapp_clean"
)

$ErrorActionPreference = "Stop"

function Get-VsInstallPath {
    $vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio\Installer\vswhere.exe"
    if (-not (Test-Path $vswhere)) { return $null }
    return (& $vswhere -latest -products * `
        -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 `
        -property installationPath 2>$null)
}

function Enter-VsDevShell {
    param([Parameter(Mandatory = $true)][string]$VsInstallPath)
    $launch = Join-Path $VsInstallPath "Common7\Tools\Launch-VsDevShell.ps1"
    if (-not (Test-Path $launch)) {
        throw "Launch-VsDevShell.ps1 missing under $VsInstallPath"
    }
    Write-Host "Entering VS Dev Shell (amd64)..."
    & $launch -SkipAutomaticLocation -Arch amd64 -HostArch amd64
}

function Resolve-VcToolsInstallDir {
    if ($env:VCToolsInstallDir) {
        return $env:VCToolsInstallDir.TrimEnd('\') + '\'
    }
    $vsInstall = Get-VsInstallPath
    if (-not $vsInstall) { return $null }
    Enter-VsDevShell -VsInstallPath $vsInstall
    if ($env:VCToolsInstallDir) {
        return $env:VCToolsInstallDir.TrimEnd('\') + '\'
    }
    return $null
}

function Resolve-ClExe {
    param([Parameter(Mandatory = $true)][string]$VcTools)
    $candidates = @(
        (Join-Path $VcTools "bin\Hostx64\x64\cl.exe"),
        (Join-Path $VcTools "bin\Hostx86\x64\cl.exe"),
        (Join-Path $VcTools "bin\Hostx86\x86\cl.exe")
    )
    foreach ($path in $candidates) {
        if (Test-Path $path) { return $path }
    }
    return $null
}

function Resolve-LinkExe {
    param([Parameter(Mandatory = $true)][string]$VcTools)
    $cl = Resolve-ClExe -VcTools $VcTools
    if (-not $cl) { return $null }
    $link = Join-Path (Split-Path $cl -Parent) "link.exe"
    if (Test-Path $link) { return $link }
    return $null
}

$vcTools = Resolve-VcToolsInstallDir
if (-not $vcTools) {
    throw @"
4E_LIVE_BLOCKED_CXX_TOOLCHAIN_NOT_INSTALLED
No VCToolsInstallDir and no VS install with VC.Tools.x86.x64 found.
Install Desktop development with C++ in Visual Studio Installer, reboot, open Developer PowerShell, retry.
"@
}

$cl = Resolve-ClExe -VcTools $vcTools
$link = Resolve-LinkExe -VcTools $vcTools
if (-not $cl -or -not $link) {
    throw "cl.exe/link.exe not found under $vcTools"
}

$excpt = Join-Path $vcTools "include\excpt.h"
if (-not (Test-Path $excpt)) {
    throw "excpt.h missing at $excpt - MSVC not fully installed."
}

$sdkRoot = Join-Path ${env:ProgramFiles(x86)} "Windows Kits\10"
if (-not (Test-Path $sdkRoot)) {
    throw "Windows 10 SDK not found."
}
$sdkVer = (Get-ChildItem (Join-Path $sdkRoot "Include") -Directory |
    Where-Object { $_.Name -match '^\d' } |
    Sort-Object { [version]$_.Name } -Descending |
    Select-Object -First 1).Name

$src = Join-Path $RepoRoot "host_boundary\mmi_wfp\mmi_wfp_helper.cpp"
if (-not (Test-Path $src)) {
    throw "Missing source: $src"
}

$outDir = Join-Path $ScratchRoot "x64\Release"
$objDir = Join-Path $ScratchRoot "x64\Release\obj"
New-Item -ItemType Directory -Force -Path $outDir, $objDir | Out-Null

$exe = Join-Path $outDir "mmi_wfp_helper.exe"
$obj = Join-Path $objDir "mmi_wfp_helper.obj"

Write-Host "CL: $cl"
Write-Host "LINK: $link"
Write-Host "VCToolsInstallDir: $vcTools"
Write-Host "WindowsSDK: $sdkVer"
Write-Host "Compiling $src"

$includeArgs = @(
    "/I`"$vcTools\include`"",
    "/I`"$sdkRoot\Include\$sdkVer\ucrt`"",
    "/I`"$sdkRoot\Include\$sdkVer\um`"",
    "/I`"$sdkRoot\Include\$sdkVer\shared`""
)
$libArgs = @(
    "/LIBPATH:`"$vcTools\lib\x64`"",
    "/LIBPATH:`"$sdkRoot\Lib\$sdkVer\ucrt\x64`"",
    "/LIBPATH:`"$sdkRoot\Lib\$sdkVer\um\x64`""
)

& $cl /nologo /EHsc /O2 /W3 /c /Fo"$obj" @includeArgs $src
if ($LASTEXITCODE -ne 0) { throw "cl compile failed." }

& $link /nologo /OUT:"$exe" @libArgs $obj fwpuclnt.lib rpcrt4.lib advapi32.lib ws2_32.lib
if ($LASTEXITCODE -ne 0) { throw "link failed." }

if (-not (Test-Path $exe)) {
    throw "Expected output not found: $exe"
}

Set-Content -Path (Join-Path $ScratchRoot "helper_path.txt") -Value $exe -Encoding ASCII
Write-Host "OK: $exe"
