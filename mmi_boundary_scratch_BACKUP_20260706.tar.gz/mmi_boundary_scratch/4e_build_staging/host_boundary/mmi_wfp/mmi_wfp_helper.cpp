// MMI WFP user-mode engine helper — Phase 4E default-deny egress for target SID.
#define WIN32_LEAN_AND_MEAN
#define INITGUID
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <fwpmu.h>
#include <stdio.h>
#include <string>
#include <vector>

#pragma comment(lib, "fwpuclnt.lib")
#pragma comment(lib, "rpcrt4.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "ws2_32.lib")

// {8f4e2a11-6b3c-4d5e-9f10-aa0b1c2d3e4f}
DEFINE_GUID(MMI_WFP_PROVIDER_KEY,
    0x8f4e2a11, 0x6b3c, 0x4d5e, 0x9f, 0x10, 0xaa, 0x0b, 0x1c, 0x2d, 0x3e, 0x4f);
// {9f5f3b22-7c4d-5e6f-a011-bb1c2d3e4f50}
DEFINE_GUID(MMI_WFP_SUBLAYER_KEY,
    0x9f5f3b22, 0x7c4d, 0x5e6f, 0xa0, 0x11, 0xbb, 0x1c, 0x2d, 0x3e, 0x4f, 0x50);
// {a06f4c33-8d5e-6f70-b122-cc2d3e4f5061}
DEFINE_GUID(MMI_WFP_ALLOW_FILTER_KEY,
    0xa06f4c33, 0x8d5e, 0x6f70, 0xb1, 0x22, 0xcc, 0x2d, 0x3e, 0x4f, 0x50, 0x61);
// {b17f5d44-9e6f-7081-c233-dd3e4f506172}
DEFINE_GUID(MMI_WFP_BLOCK_FILTER_KEY,
    0xb17f5d44, 0x9e6f, 0x7081, 0xc2, 0x33, 0xdd, 0x3e, 0x4f, 0x50, 0x61, 0x72);

static std::string ReadFileUtf8(const char* path) {
    FILE* f = nullptr;
    fopen_s(&f, path, "rb");
    if (!f) return {};
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    std::string data;
    if (size > 0) {
        data.resize(static_cast<size_t>(size));
        fread(data.data(), 1, data.size(), f);
    }
    fclose(f);
    return data;
}

static std::string ExtractJsonString(const std::string& json, const char* key) {
    std::string needle = std::string("\"") + key + "\":";
    size_t pos = json.find(needle);
    if (pos == std::string::npos) return {};
    pos = json.find('"', pos + needle.size());
    if (pos == std::string::npos) return {};
    size_t end = json.find('"', pos + 1);
    if (end == std::string::npos) return {};
    return json.substr(pos + 1, end - pos - 1);
}

static int ExtractJsonInt(const std::string& json, const char* key, int fallback) {
    std::string needle = std::string("\"") + key + "\":";
    size_t pos = json.find(needle);
    if (pos == std::string::npos) return fallback;
    pos += needle.size();
    return atoi(json.c_str() + pos);
}

static bool SidToBlob(const std::string& sid, std::vector<BYTE>& out) {
    PSID psid = nullptr;
    if (!ConvertStringSidToSidA(sid.c_str(), &psid)) return false;
    DWORD size = GetLengthSid(psid);
    out.assign(size, 0);
    CopySid(size, out.data(), psid);
    LocalFree(psid);
    return true;
}

static bool WriteState(const std::string& evidenceDir, bool loaded, UINT32 filterCount, const std::string& sid) {
    std::string path = evidenceDir + "\\wfp_engine_state.json";
    FILE* f = nullptr;
    fopen_s(&f, path.c_str(), "wb");
    if (!f) return false;
    fprintf(
        f,
        "{\n  \"engine_name\": \"mmi_wfp\",\n  \"loaded\": %s,\n  \"filter_count\": %u,\n  \"target_clone_sid\": \"%s\"\n}\n",
        loaded ? "true" : "false",
        filterCount,
        sid.c_str());
    fclose(f);
    return true;
}

static DWORD InstallFilters(HANDLE engine, const std::string& sid, const std::string& allowHost, UINT16 allowPort) {
    static wchar_t providerName[] = L"MMI WFP Boundary";
    static wchar_t providerDesc[] = L"MMI Phase 4E default-deny egress";
    static wchar_t sublayerName[] = L"MMI WFP SubLayer";
    static wchar_t allowName[] = L"MMI WFP Allow Telemetry";
    static wchar_t blockName[] = L"MMI WFP Default Deny";

    FWPM_PROVIDER0 provider = {};
    provider.providerKey = MMI_WFP_PROVIDER_KEY;
    provider.displayData.name = providerName;
    provider.displayData.description = providerDesc;
    DWORD result = FwpmProviderAdd0(engine, &provider, NULL);
    if (result != ERROR_SUCCESS && result != FWP_E_ALREADY_EXISTS) return result;

    FWPM_SUBLAYER0 sublayer = {};
    sublayer.subLayerKey = MMI_WFP_SUBLAYER_KEY;
    sublayer.displayData.name = sublayerName;
    sublayer.providerKey = &MMI_WFP_PROVIDER_KEY;
    sublayer.weight = 0x100;
    result = FwpmSubLayerAdd0(engine, &sublayer, NULL);
    if (result != ERROR_SUCCESS && result != FWP_E_ALREADY_EXISTS) return result;

    std::vector<BYTE> sidBlob;
    if (!SidToBlob(sid, sidBlob)) return ERROR_INVALID_SID;

    FWP_BYTE_BLOB sidCondition = {};
    sidCondition.size = static_cast<UINT32>(sidBlob.size());
    sidCondition.data = sidBlob.data();

    IN_ADDR allowAddr = {};
    allowAddr.S_un.S_addr = inet_addr(allowHost.c_str());

    FWP_V4_ADDR_AND_MASK allowRemote = {};
    allowRemote.addr = allowAddr;
    allowRemote.mask = {0xFFFFFFFF};

    FWPM_FILTER_CONDITION0 allowConds[3] = {};
    allowConds[0].fieldKey = FWPM_CONDITION_ALE_USER_ID;
    allowConds[0].matchType = FWP_MATCH_EQUAL;
    allowConds[0].conditionValue.type = FWP_SID;
    allowConds[0].conditionValue.sid = &sidCondition;

    allowConds[1].fieldKey = FWPM_CONDITION_IP_REMOTE_ADDRESS;
    allowConds[1].matchType = FWP_MATCH_EQUAL;
    allowConds[1].conditionValue.type = FWP_V4_ADDR_MASK;
    allowConds[1].conditionValue.v4AddrMask = &allowRemote;

    allowConds[2].fieldKey = FWPM_CONDITION_IP_REMOTE_PORT;
    allowConds[2].matchType = FWP_MATCH_EQUAL;
    allowConds[2].conditionValue.type = FWP_UINT16;
    allowConds[2].conditionValue.uint16 = allowPort;

    FWPM_FILTER0 allowFilter = {};
    allowFilter.filterKey = MMI_WFP_ALLOW_FILTER_KEY;
    allowFilter.displayData.name = allowName;
    allowFilter.layerKey = FWPM_LAYER_ALE_AUTH_CONNECT_V4;
    allowFilter.subLayerKey = MMI_WFP_SUBLAYER_KEY;
    allowFilter.weight.type = FWP_UINT8;
    allowFilter.weight.uint8 = 10;
    allowFilter.action.type = FWP_ACTION_PERMIT;
    allowFilter.numFilterConditions = 3;
    allowFilter.filterCondition = allowConds;
    result = FwpmFilterAdd0(engine, &allowFilter, NULL, NULL);
    if (result != ERROR_SUCCESS && result != FWP_E_ALREADY_EXISTS) return result;

    FWPM_FILTER_CONDITION0 blockConds[1] = {};
    blockConds[0].fieldKey = FWPM_CONDITION_ALE_USER_ID;
    blockConds[0].matchType = FWP_MATCH_EQUAL;
    blockConds[0].conditionValue.type = FWP_SID;
    blockConds[0].conditionValue.sid = &sidCondition;

    FWPM_FILTER0 blockFilter = {};
    blockFilter.filterKey = MMI_WFP_BLOCK_FILTER_KEY;
    blockFilter.displayData.name = blockName;
    blockFilter.layerKey = FWPM_LAYER_ALE_AUTH_CONNECT_V4;
    blockFilter.subLayerKey = MMI_WFP_SUBLAYER_KEY;
    blockFilter.weight.type = FWP_UINT8;
    blockFilter.weight.uint8 = 20;
    blockFilter.action.type = FWP_ACTION_BLOCK;
    blockFilter.numFilterConditions = 1;
    blockFilter.filterCondition = blockConds;
    result = FwpmFilterAdd0(engine, &blockFilter, NULL, NULL);
    if (result != ERROR_SUCCESS && result != FWP_E_ALREADY_EXISTS) return result;

    return ERROR_SUCCESS;
}

static DWORD UninstallFilters(HANDLE engine) {
    FwpmFilterDeleteByKey0(engine, &MMI_WFP_ALLOW_FILTER_KEY);
    FwpmFilterDeleteByKey0(engine, &MMI_WFP_BLOCK_FILTER_KEY);
    FwpmSubLayerDeleteByKey0(engine, &MMI_WFP_SUBLAYER_KEY);
    FwpmProviderDeleteByKey0(engine, &MMI_WFP_PROVIDER_KEY);
    return ERROR_SUCCESS;
}

static int CmdInstall(const char* configPath) {
    std::string json = ReadFileUtf8(configPath);
    if (json.empty()) return 1;
    std::string sid = ExtractJsonString(json, "target_clone_sid");
    std::string evidence = ExtractJsonString(json, "evidence_dir");
    std::string allowHost = ExtractJsonString(json, "host");
    if (allowHost.empty()) allowHost = "127.0.0.1";
    int allowPort = ExtractJsonInt(json, "port", 9443);
    if (sid.empty() || evidence.empty()) return 1;

    HANDLE engine = NULL;
    DWORD result = FwpmEngineOpen0(NULL, RPC_C_AUTHN_WINNT, NULL, NULL, &engine);
    if (result != ERROR_SUCCESS) return (int)result;

    FwpmTransactionBegin0(engine, 0);
    result = InstallFilters(engine, sid, allowHost, static_cast<UINT16>(allowPort));
    if (result == ERROR_SUCCESS) {
        FwpmTransactionCommit0(engine);
        WriteState(evidence, true, 2, sid);
    } else {
        FwpmTransactionAbort0(engine);
    }
    FwpmEngineClose0(engine);
    return result == ERROR_SUCCESS ? 0 : (int)result;
}

static int CmdUninstall(const char* configPath) {
    std::string evidence;
    if (configPath) {
        std::string json = ReadFileUtf8(configPath);
        evidence = ExtractJsonString(json, "evidence_dir");
    }
    HANDLE engine = NULL;
    DWORD result = FwpmEngineOpen0(NULL, RPC_C_AUTHN_WINNT, NULL, NULL, &engine);
    if (result != ERROR_SUCCESS) return (int)result;
    FwpmTransactionBegin0(engine, 0);
    UninstallFilters(engine);
    FwpmTransactionCommit0(engine);
    FwpmEngineClose0(engine);
    if (!evidence.empty()) WriteState(evidence, false, 0, "");
    return 0;
}

static int CmdStatus() {
    HANDLE engine = NULL;
    DWORD result = FwpmEngineOpen0(NULL, RPC_C_AUTHN_WINNT, NULL, NULL, &engine);
    if (result != ERROR_SUCCESS) {
        printf("{\"loaded\":false,\"filter_count\":0,\"engine_name\":\"mmi_wfp\"}\n");
        return 1;
    }
    FWPM_FILTER0* filter = NULL;
    UINT32 loaded = 0;
    if (FwpmFilterGetByKey0(engine, &MMI_WFP_ALLOW_FILTER_KEY, &filter) == ERROR_SUCCESS) {
        loaded++;
        FwpmFreeMemory0((void**)&filter);
    }
    if (FwpmFilterGetByKey0(engine, &MMI_WFP_BLOCK_FILTER_KEY, &filter) == ERROR_SUCCESS) {
        loaded++;
        FwpmFreeMemory0((void**)&filter);
    }
    FwpmEngineClose0(engine);
    printf("{\"loaded\":%s,\"filter_count\":%u,\"engine_name\":\"mmi_wfp\"}\n",
           loaded >= 2 ? "true" : "false", loaded);
    return loaded >= 2 ? 0 : 1;
}

int main(int argc, char** argv) {
    WSADATA wsa = {};
    WSAStartup(MAKEWORD(2, 2), &wsa);
    if (argc < 2) return 1;
    if (_stricmp(argv[1], "install") == 0) {
        const char* config = "--config";
        for (int i = 2; i < argc - 1; ++i) {
            if (_stricmp(argv[i], "--config") == 0) return CmdInstall(argv[i + 1]);
        }
        return 1;
    }
    if (_stricmp(argv[1], "uninstall") == 0) {
        const char* config = NULL;
        for (int i = 2; i < argc - 1; ++i) {
            if (_stricmp(argv[i], "--config") == 0) config = argv[i + 1];
        }
        return CmdUninstall(config);
    }
    if (_stricmp(argv[1], "status") == 0) {
        return CmdStatus();
    }
    return 1;
}
