# Phase 4E — WFP default-deny egress (T7)

## Scope

User-mode WFP engine helper registers default-deny outbound connect filters for the
**target clone/probe SID** at `FWPM_LAYER_ALE_AUTH_CONNECT_V4`, with a single
telemetry allowlist entry from signed `policy_manifest.json` (`wfp_policy`).

## Non-inheritance

```text
4E does not prove file-boundary containment.
4D_b does not prove network egress containment.
NOT CLAIMED: host containment, M4_MET, GATED, PERFECT.
```

## Build (PC1, VS 2022 + Windows SDK)

```powershell
cd C:\Architectapp_clean
.\scripts\build_m4_wfp.ps1
```

## Install (Administrator)

Install binds filters to the **current interactive user SID** and writes
`C:\mmi_m4_evidence\boundary\wfp_engine_state.json`.

```powershell
.\scripts\install_m4_wfp.ps1
```

Re-seal policy after code deploy if authority tree changed:

```powershell
python scripts\m4_authority_seal.py --store --json
```

## Live gate

```powershell
python scripts\m4_wfp_suite.py --live --json
```

Required selftest keys: `wfp_loaded`, `source_context_ok`, `live_t7_blocked`,
`live_telemetry_ok`, `min_viable_live_t7`.

## Source context (P4E-B5)

Live probes run from the install-target SID (current admin/interactive user at install).
If identity does not match `wfp_engine_state.json` / manifest target, suite fails closed.

## Evidence

| Artifact | Path |
|----------|------|
| Deny stream | `boundary/wfp_denies.jsonl` |
| Suite rollup | `boundary/wfp_suite_summary.json` |
| T7 falsifier | `boundary/falsifiers/T7_summary.json` |

## Uninstall

```powershell
.\scripts\uninstall_m4_wfp.ps1
```
