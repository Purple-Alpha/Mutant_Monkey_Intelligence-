# Build MMI WFP user-mode helper (Phase 4E).
param(
    [switch]$TestSign
)

$ErrorActionPreference = "Stop"

function Find-Vs2022MsBuild {
    $vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio\Installer\vswhere.exe"
    if (Test-Path $vswhere) {
        $installPath = & $vswhere -latest -version "[17.0,18.0)" -products * -requires Microsoft.Component.MSBuild -property installationPath 2>$null
        if ($installPath) {
            $candidate = Join-Path $installPath "MSBuild\Current\Bin\amd64\MSBuild.exe"
            if (Test-Path $candidate) { return $candidate }
        }
    }
    return $null
}

$repoRoot = Split-Path -Parent $PSScriptRoot
$projectDir = Join-Path $repoRoot "host_boundary\mmi_wfp"
$project = Join-Path $projectDir "mmi_wfp_helper.vcxproj"

$msbuild = Find-Vs2022MsBuild
if (-not $msbuild) {
    throw "Visual Studio 2022 MSBuild not found."
}

Write-Host "Building $project"
& $msbuild $project '/p:Configuration=Release' '/p:Platform=x64' '/restore' '/v:m'
if ($LASTEXITCODE -ne 0) {
    throw "MSBuild failed for mmi_wfp_helper."
}

$exe = Join-Path $projectDir "x64\Release\mmi_wfp_helper.exe"
if (-not (Test-Path $exe)) {
    throw "Expected output not found: $exe"
}

Write-Host "OK: $exe"
