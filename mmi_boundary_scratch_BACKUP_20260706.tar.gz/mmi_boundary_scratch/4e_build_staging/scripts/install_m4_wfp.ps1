# Install/load MMI WFP default-deny engine (Phase 4E) — Administrator required.
param(
    [string]$AuthorityRoot = "C:\Architectapp_clean",
    [string]$EvidenceRoot = "C:\mmi_m4_evidence\boundary",
    [switch]$SkipBuild
)

$ErrorActionPreference = "Stop"

function Test-Admin {
    $current = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
    return $current.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Admin)) {
    throw "Run as Administrator."
}

$repoRoot = Split-Path -Parent $PSScriptRoot
$helperProject = Join-Path $repoRoot "host_boundary\mmi_wfp"
$helperExe = Join-Path $helperProject "x64\Release\mmi_wfp_helper.exe"

if (-not $SkipBuild) {
    & (Join-Path $repoRoot "scripts\build_m4_wfp.ps1")
}

if (-not (Test-Path $helperExe)) {
    throw "Missing built helper: $helperExe"
}

$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$targetSid = $identity.User.Value
Write-Host "Target clone/probe SID: $targetSid"

New-Item -ItemType Directory -Force -Path $EvidenceRoot | Out-Null

$config = @{
    engine_name = "mmi_wfp"
    target_clone_sid = $targetSid
    host = "127.0.0.1"
    port = 9443
    evidence_dir = $EvidenceRoot
} | ConvertTo-Json -Depth 4

$configPath = Join-Path $EvidenceRoot "wfp_install_config.json"
Set-Content -Path $configPath -Value $config -Encoding UTF8

& $helperExe install --config $configPath
if ($LASTEXITCODE -ne 0) {
    throw "mmi_wfp_helper install failed with exit code $LASTEXITCODE"
}

$status = & $helperExe status --json | ConvertFrom-Json
Write-Host ($status | ConvertTo-Json -Compress)
if (-not $status.loaded) {
    throw "WFP engine not loaded after install."
}

Write-Host "WFP engine installed. Run: python scripts/m4_wfp_suite.py --live --json"
